# Viola Online Store
Web Static Bertemakan Toko Online 

![Preview Viola Store](/Viola-Online-Store-Homepage.png "Preview Viola Store")


## Demo
[link](https://violastore.netlify.app/index.html)

### Ini adalah Salah satu Fake Project yang saya buat

Fake Project ini di tunjukan untuk para pelaku umkm yang ingin mempunyai suatu wadah bagi para calon pembeli untuk melihat -lihat 
product apa saja yang sedang di jual, dan yang lagi trend, bahkan product baru sekalipun

*Note : Web ini masih bersifat statis, yang artinya belum bisa menerima pembayaran dan orderan, suatu saat akan di update*

## Berikut Library yang membantu saya 
* Bootstrap
* Aos

### Panduan Instalasi
1. Download Zip / Clone
2. Ekstrak zip (jika mendownload versi zip)
3. Double Klik file index.html
4. finish
